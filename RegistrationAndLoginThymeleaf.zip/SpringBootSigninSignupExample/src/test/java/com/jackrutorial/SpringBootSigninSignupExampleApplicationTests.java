package com.jackrutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSigninSignupExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
